#!/bin/sh
# Shell script to start Vim with less.vim.
# Read stdin if no arguments were given.
# Note: Doesn't seem to work when full path is used with the runtime! command
# Note: The runtime command doesn't report error messages

VIM_FLAGS='-p -R -Z -m -M'

if test $# = 0; then
  vim $VIM_FLAGS --cmd 'let no_plugin_maps = 1' -c 'runtime! less.vim' -
else
  vim $VIM_FLAGS --cmd 'let no_plugin_maps = 1' -c 'runtime! less.vim' "$@"
fi
