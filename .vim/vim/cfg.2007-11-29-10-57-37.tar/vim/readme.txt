All soft links

ln -s $CFG/vim/vimrc ~/.vimrc 
ln -s $CFG/vim ~/.vim 
