#!/bin/sh
#
# Execute as sudo
#

/etc/acpi/hibernate.sh
