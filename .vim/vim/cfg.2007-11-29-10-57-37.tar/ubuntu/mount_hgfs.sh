#!/bin/sh

# Note: First make sure VMware tools are installed

UID=`id -u`
GID=`id -g`
CMD="mount -t vmhgfs -o uid=$UID,gid=$GID,rw .host:/share /mnt/hgfs/share"
echo $CMD
sudo $CMD
