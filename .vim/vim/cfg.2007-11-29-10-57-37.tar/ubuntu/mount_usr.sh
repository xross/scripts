#!/bin/sh

# Note: First make sure CIFS is installed
# sudo apt-get install smbfs

CMD="mount -t cifs //10.0.102.12/usr /mnt/jay/usr -o username=$USER,uid=$USER"
echo $CMD

echo "Sudo password first"
sudo echo "Domain password now"

sudo $CMD
