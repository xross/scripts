#!/bin/sh
sudo dhclient3 eth0
