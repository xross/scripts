#!/bin/sh

FILER_IP=10.0.102.16
FILER_HOME=/vol0/home
MOUNT_POINT=/mnt/filer/home

CMD="mount -t nfs $FILER_IP:$FILER_HOME $MOUNT_POINT"
echo $CMD
sudo $CMD
