#!/bin/sh

sudo date

CMD1='/etc/init.d/networking stop'
CMD2='rmmod pcnet32'
CMD3='rmmod vmxnet'
CMD4='modprobe vmxnet'
CMD5='/etc/init.d/networking start'

echo $CMD1
sudo $CMD1
echo $CMD2
#sudo $CMD2
echo $CMD3
sudo $CMD3
echo $CMD4
sudo $CMD4
echo $CMD5
sudo $CMD5
